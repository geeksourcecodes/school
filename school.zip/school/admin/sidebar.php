<aside id="sidebar" class="column">
		<form class="quick_search">
			<input type="text" value="Quick Search" onfocus="if(!this._haschanged){this.value=''};this._haschanged=true;">
		</form>
		<hr/>
		<h3>Content</h3>
		<ul class="toggle">
			<li class="icn_new_article"><a href="http://localhost/school/admin/dashboard.php#post">New Article</a></li>
			<li class="icn_categories"><a href="#">Services</a></li>
			<li class="icn_tags"><a href="contact.php">Contact Us</a></li>
		</ul>
		<h3>Users</h3>
		<ul class="toggle">
			<li class="icn_add_user"><a href="http://localhost/school/admin/new_user.php">Add New Member</a></li>
			<li class="icn_view_users"><a href="http://localhost/school/admin/user_record.php">View Members</a></li>
			<li class="icn_profile"><a href="profile.php">Your Profile</a></li>
		</ul>
		<h3>Media</h3>
		<ul class="toggle">
			<li class="icn_photo"><a href="http://localhost/school/admin/media.php">Gallery</a></li>
			<li class="icn_audio"><a href="#">Audio</a></li>
			<li class="icn_video"><a href="#">Video</a></li>
		</ul>
		<h3>Admin</h3>
		<ul class="toggle">
			<li class="icn_settings"><a href="#">Options</a></li>
			<li class="icn_security"><a href="#">Security</a></li>
			<li class="icn_jump_back"><a href="logout.php">Logout</a></li>
		</ul>
		
		<footer>
			<hr />
			<p><strong>Copyright &copy; 2017 Website Admin</strong></p>
		</footer>
	</aside><!-- end of sidebar -->