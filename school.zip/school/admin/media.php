<html>
<head>
<?php 
  include'header.php';
  include'sidebar.php';

?>
</head>
<body>
<a href="http://localhost/school"><img src="images/bg-homepage.jpg" alt="homepage" height="449" width="359"></a>
<a href="http://localhost/school"><img src="images/baby-smiling.gif" alt="Home_footer" height="449" width="359"></a>
<a href="http://localhost/school"><img src="images/playing-in-grass.gif" alt="Home_footer" height="449" width="359"></a>
<a href="http://localhost/school"><img ssrc="images/logo.gif" alt="logo" height="449" width="359"></a>
<a href="http://localhost/school/contact.php"><img src="images/calling.jpg" alt="calling" height="449" width="359"></a>	
</body>
</html>