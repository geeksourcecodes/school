<!DOCTYPE html>
<html>
<head>
<title>Special School</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="css/style.css">
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="css/ie6.css"><![endif]-->
</head>
<body>
<div id="header">
  <div> <a href="index.php"><img src="images/logo.gif" alt=""></a>
    <ul>
      <li class="current"><a href="index.php">Home</a></li>
      <li><a href="about.php">About us</a></li>
      <li><a href="blog.php">Blog</a></li>
      <li><a href="contact.php">Contact us</a></li>
      <li><a href="login.php">Login</a></li>
      <li><a href="register.php"><input type="submit" value="Register" style="background-color:#4CAF50; color: white; border-radius:20px; font-size: 20px; "></a></li>
    </ul>


  </div>
</div>