<div id="footer">
  <div>
    <div> <span>Follow us</span> <a href="https://www.facebook.com" class="facebook">Facebook</a> <a href="https://www.gmail.com/" class="subscribe">Subscribe</a> <a href="http://www.twitter.com" class="twitter">Twitter</a> <a href="https://www.flickr.com/" class="flicker">Flickr</a> </div>
    <ul>
      <li> 
        <a href="#"><img src="images/playing-in-grass.gif" alt=""></a>
       
      <li> <a href="#"><img src="images/baby-smiling.gif" alt=""></a>
        
    </ul>
  </div>
  <p class="footnote">Copyright &copy; 2017 <a href="#">School Name</a> All rights reserved | Geeksourcecodes By <a target="_blank" href="https://geeksourcecodes.com/">geeksourcecodes.com</a></p>
</div>
</body>
</html>
